// Shared list of tracking parameters (used by service worker, popup and tests).
export const TRACKING_PARAMS = [
  'utm_source', 'utm_medium', 'utm_campaign', 'utm_term', 'utm_content', 'utm_id', 'utm_name', 'utm_reader', 'utm_brand', 'utm_social', 'utm_social-type',
  'fbclid', 'gclid', 'gclsrc', 'dclid', 'gbraid', 'wbraid', 'msclkid', 'yclid', 'twclid', 'ttclid', 'li_fat_id', 'igshid', 'igsh',
  'mc_cid', 'mc_eid', '_hsenc', '_hsmi', 'hsCtaTracking', 'mkt_tok', 'oly_anon_id', 'oly_enc_id', 'vero_id', 'wickedid',
  '_openstat', 'rb_clickid', 's_cid', 'ef_id', 'srsltid', 'gad_source', 'gad_campaignid', '_ga', '_gl', 'spm', 'scm', '__twitter_impression', 'ref_src', 'ref_url',
];
const SET = new Set(TRACKING_PARAMS.map((p) => p.toLowerCase()));

// Parameters that are tracking only on specific sites (too generic to strip everywhere, e.g. "si", "t", "sr").
const AMAZON = ['amazon.de', 'amazon.com', 'amazon.co.uk', 'amazon.fr', 'amazon.it', 'amazon.es', 'amazon.nl', 'amazon.pl', 'amazon.se', 'amazon.com.be', 'amazon.at', 'amazon.ca', 'amazon.com.au', 'amazon.co.jp', 'amazon.in', 'amazon.com.mx', 'amazon.com.br', 'amazon.com.tr'];
export const SITE_PARAMS = [
  { domains: ['youtube.com', 'youtu.be', 'open.spotify.com'], params: ['si', 'pp', 'feature'] },
  { domains: AMAZON, params: ['pd_rd_w', 'pd_rd_wg', 'pd_rd_r', 'pd_rd_i', 'pf_rd_p', 'pf_rd_r', 'pf_rd_s', 'pf_rd_t', 'pf_rd_i', 'pf_rd_m', 'qid', 'sr', 'crid', 'sprefix', '_encoding', 'content-id', 'dib', 'dib_tag', 'ref_'] },
  { domains: ['tiktok.com'], params: ['_t', '_r', 'is_from_webapp', 'sender_device', 'is_copy_url'] },
  { domains: ['x.com', 'twitter.com'], params: ['s', 't'] },
  { domains: ['facebook.com'], params: ['__tn__', '__cft__[0]', '__eep__', 'mibextid'] },
  { domains: ['reddit.com'], params: ['share_id', 'rdt'] },
  { domains: ['ebay.de', 'ebay.com', 'ebay.co.uk', 'ebay.fr', 'ebay.it', 'ebay.es', 'ebay.at', 'ebay.ch'], params: ['_trkparms', '_trksid', '_from', 'hash'] },
];
const onDomain = (host, list) => list.some((d) => host === d || host.endsWith(`.${d}`));
const siteParams = (host) => SITE_PARAMS.filter((r) => onDomain(host, r.domains)).flatMap((r) => r.params);

/** Returns {url, removed[]} with tracking params stripped. extra = user rules (Pro). */
export function cleanUrl(input, extra = []) {
  let u;
  try { u = new URL(input); } catch { return { url: input, removed: [] }; }
  if (!/^https?:$/.test(u.protocol)) return { url: input, removed: [] };
  const extraSet = new Set([...extra, ...siteParams(u.hostname.toLowerCase())].map((p) => p.toLowerCase()));
  const removed = [];
  for (const key of [...u.searchParams.keys()]) {
    const k = key.toLowerCase();
    if (SET.has(k) || extraSet.has(k) || k.startsWith('utm_')) { removed.push(key); }
  }
  if (onDomain(u.hostname.toLowerCase(), AMAZON) && /\/ref=[^/]*$/.test(u.pathname)) { u.pathname = u.pathname.replace(/\/ref=[^/]*$/, ''); removed.push('/ref='); }
  if (!removed.length) return { url: input, removed };
  for (const k of removed) u.searchParams.delete(k);
  let out = u.toString();
  if (!u.searchParams.toString()) out = out.replace(/\?(?=#|$)/, '');
  return { url: out, removed: [...new Set(removed)] };
}

/** Amazon short link: https://www.amazon.de/dp/ASIN */
export function shortenAmazon(input) {
  try {
    const u = new URL(input);
    if (!/(^|\.)amazon\.[a-z.]+$/.test(u.hostname)) return null;
    const m = u.pathname.match(/\/(?:dp|gp\/product|gp\/aw\/d)\/([A-Z0-9]{10})/i);
    return m ? `${u.origin}/dp/${m[1].toUpperCase()}` : null;
  } catch { return null; }
}

// Sites where URL rewriting is known to break logins/apps (ClearURLs' most common complaint). Never touched.
export const DEFAULT_SKIP = ['accounts.google.com', 'docs.google.com', 'mail.google.com', 'appleid.apple.com', 'login.microsoftonline.com'];

/** Normalise user input ("https://www.Shop.de/x") to a registrable host ("shop.de"); null if invalid. */
export function normalizeDomain(input) {
  let s = String(input || '').trim().toLowerCase();
  if (!s) return null;
  try { s = new URL(s.includes('://') ? s : `https://${s}`).hostname; } catch { return null; }
  s = s.replace(/^www\./, '');
  return /^[a-z0-9-]+(\.[a-z0-9-]+)+$/.test(s) ? s : null;
}

/** True if host is on (or a subdomain of) the skip list. */
export function isSkipped(url, skip = []) {
  let h; try { h = new URL(url).hostname.toLowerCase(); } catch { return false; }
  return [...DEFAULT_SKIP, ...skip].some((d) => h === d || h.endsWith(`.${d}`));
}

// Redirect wrappers: the real target sits in one query parameter.
const WRAPPERS = [
  [/^(www\.)?google\.[a-z.]+$/, '/url', ['q', 'url']],
  [/^l\.facebook\.com$|^lm\.facebook\.com$/, '/l.php', ['u']],
  [/^l\.instagram\.com$/, '/', ['u']],
  [/^out\.reddit\.com$/, null, ['url']],
  [/^(www\.)?youtube\.com$/, '/redirect', ['q']],
  [/^(www\.)?linkedin\.com$/, '/redir/redirect', ['url']],
];
/** Returns the wrapped target URL (http/https only) or null. */
export function unwrapRedirect(input) {
  let u; try { u = new URL(input); } catch { return null; }
  for (const [host, path, keys] of WRAPPERS) {
    if (!host.test(u.hostname) || (path && u.pathname !== path)) continue;
    for (const k of keys) {
      const v = u.searchParams.get(k);
      if (v && /^https?:\/\//i.test(v)) { try { return new URL(v).toString(); } catch { /* ignore */ } }
    }
  }
  return null;
}

/** Full copy pipeline: unwrap redirect wrapper, then strip tracking. */
export function cleanForCopy(input, extra = []) {
  const target = unwrapRedirect(input);
  const r = cleanUrl(target || input, extra);
  return { ...r, unwrapped: !!target };
}

/** declarativeNetRequest rules for automatic cleaning (used by background.js and the benchmark simulator).
 * Only one redirect rule applies per request, so every rule carries the FULL removeParams list for its scope;
 * the regexFilter (trigger) is split into small chunks because Chrome caps each compiled regex at 2 KB.
 * Site rules have higher priority and include the global list. */
const esc = (x) => x.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
const CHUNK = 8;
export function buildRules({ enabled = true, extra = [], pro = false, skip = [] } = {}) {
  if (!enabled) return [];
  const global = [...new Set([...TRACKING_PARAMS, ...(pro ? extra : [])])];
  const rules = []; let id = 1;
  const add = (priority, removeParams, triggers, cond) => {
    for (let i = 0; i < triggers.length; i += CHUNK) {
      rules.push({ id: id++, priority,
        action: { type: 'redirect', redirect: { transform: { queryTransform: { removeParams } } } },
        condition: { resourceTypes: ['main_frame'], excludedRequestDomains: [...DEFAULT_SKIP, ...skip], isUrlFilterCaseSensitive: true,
          regexFilter: `[?&](${triggers.slice(i, i + CHUNK).map(esc).join('|')})=`, ...cond } });
    }
  };
  add(1, global, global, {});
  for (const r of SITE_PARAMS) { const all = [...new Set([...global, ...r.params])]; add(2, all, r.params, { requestDomains: r.domains }); }
  return rules;
}
