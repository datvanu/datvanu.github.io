import { buildRules } from './params.js';

async function applyRules() {
  const opts = await chrome.storage.sync.get(['enabled', 'extra', 'pro', 'skip']);
  const old = await chrome.declarativeNetRequest.getDynamicRules();
  await chrome.declarativeNetRequest.updateDynamicRules({ removeRuleIds: old.map((r) => r.id), addRules: buildRules(opts) });
}
chrome.runtime.onInstalled.addListener(applyRules);
chrome.runtime.onStartup.addListener(applyRules);
chrome.storage.onChanged.addListener(applyRules);

// Show per-tab count of cleaned navigations as badge (no extra permission, nothing stored remotely).
chrome.declarativeNetRequest.setExtensionActionOptions({ displayActionCountAsBadgeText: true });
