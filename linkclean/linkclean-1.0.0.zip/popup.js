import { cleanForCopy, shortenAmazon, normalizeDomain, isSkipped } from './params.js';
const $ = (id) => document.getElementById(id);
const t = (k, s) => chrome.i18n.getMessage(k, s) || k;
document.querySelectorAll('[data-i18n]').forEach((el) => { el.textContent = t(el.dataset.i18n); });

// ?tab=<id> lets tests/screenshots open the popup as a page while targeting a real web tab.
const forced = Number(new URLSearchParams(location.search).get('tab'));
const tab = forced ? await chrome.tabs.get(forced) : (await chrome.tabs.query({ active: true, currentWindow: true }))[0];
const { enabled = true, extra = [], pro = false, skip = [] } = await chrome.storage.sync.get(['enabled', 'extra', 'pro', 'skip']);
const { count = 0 } = await chrome.storage.local.get('count');
$('enabled').checked = enabled; $('count').textContent = count; $('extra').value = extra.join(', ');
// Pro unlock is planned via ExtensionPay (one-time purchase). Not wired up until the store/Stripe account exists.
for (const id of ['amazon', 'extra', 'save']) $(id).disabled = !pro;
$('locked').hidden = pro;

$('enabled').onchange = (e) => chrome.storage.sync.set({ enabled: e.target.checked });
$('copy').onclick = async () => {
  const { url, removed } = cleanForCopy(tab.url, pro ? extra : []);
  await navigator.clipboard.writeText(url);
  await chrome.storage.local.set({ count: count + 1 }); $('count').textContent = count + 1;
  $('status').textContent = removed.length ? t('copiedRemoved', [String(removed.length)]) : t('copiedNothing');
};
$('amazon').onclick = async () => {
  const s = shortenAmazon(tab.url);
  if (s) { await navigator.clipboard.writeText(s); $('status').textContent = t('copiedNothing'); } else $('status').textContent = t('notAmazon');
};
$('save').onclick = async () => {
  const list = $('extra').value.split(/[\s,]+/).map((x) => x.trim()).filter((x) => /^[\w.-]{1,40}$/.test(x)).slice(0, 50);
  await chrome.storage.sync.set({ extra: list }); $('status').textContent = t('saved');
};

// Free: pause automatic cleaning on the current site (fixes broken logins/apps without disabling everything).
const host = normalizeDomain(tab.url);
const renderSkip = () => { $('skip').textContent = t(isSkipped(tab.url, skip) ? 'resumeSite' : 'pauseSite'); };
renderSkip(); if (!host) $('skip').disabled = true;
$('skip').onclick = async () => {
  const i = skip.indexOf(host);
  if (i >= 0) skip.splice(i, 1); else if (!isSkipped(tab.url, skip)) skip.push(host); else return;
  await chrome.storage.sync.set({ skip: skip.slice(0, 200) }); renderSkip();
};
